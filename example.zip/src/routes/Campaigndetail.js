

const Campaigndetail = () => {
    return (
        <div>
            캠페인 개별
        </div>
    )
}


export default Campaigndetail;