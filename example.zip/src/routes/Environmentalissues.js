

const Environmentalissues = () => {
    return (
        <div>
            이슈
        </div>
    )
}

export default Environmentalissues;