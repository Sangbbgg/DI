import { useNavigate } from "react-router-dom";

const Community = () => {

    const navigate = useNavigate();

    const goWrite = () => {
        navigate('/community/write')
    }

    return (
        <div>
            <button onClick={goWrite}>글쓰기</button>
        </div>
    )
}

export default Community;