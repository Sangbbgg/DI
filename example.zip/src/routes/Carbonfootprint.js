

const Carbonfootprint = () => {
    return (
        <div>
            발자국
        </div>
    )
}

export default Carbonfootprint;