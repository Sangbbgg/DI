import { useNavigate } from "react-router-dom";

const Write = () => {

    

    return (
        <div>
            등록
        </div>
    )
}

export default Write;