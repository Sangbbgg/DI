

const Mypage = () => {
    return (
        <div>
            마이페이지
        </div>
    )
}

export default Mypage;