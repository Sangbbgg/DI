import { useNavigate, Link } from 'react-router-dom'
import styles from './Home.css'


const Home = () => {

    const navigate = useNavigate();

    const goLogin = () => {
        navigate('/login');
    }

    const goInfor = () => {
        navigate('/findinformation');
    }

    const goRegister = () => {
        navigate('/register')
    }

    return (
        <div className={styles.container}>
            <div className={styles.btnlist}>
                <button onClick={goLogin}>로그인하기</button>
                <button onClick={goInfor}>아이디,비밀번호찾기</button>
                <button onClick={goRegister}>회원가입</button>
            </div>
            <ul>
                <li>
                    <Link to={'/carbonfootprint'}>
                        탄소발자국
                    </Link>
                </li>
                <li>
                    <Link to={'/environmentalissues'}>
                        환경이슈
                    </Link>
                </li>
                <li>
                    <Link to={'/community'}>
                        커뮤니티
                    </Link>
                </li>
                <li>
                    <Link to={'/campaign'}>
                        캠페인
                    </Link>
                </li>
                <li>
                    <Link to={'/shop'}>
                        빵끗샵
                    </Link>
                </li>
            </ul>
        </div>
    )
}


export default Home;