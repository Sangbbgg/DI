

const Product = () => {
    return (
        <div>
            상품 상세
        </div>
    )
}

export default Product;