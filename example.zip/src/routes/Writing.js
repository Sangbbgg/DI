

const Writing = () => {
    return (
        <div>
            개별 글
        </div>
    )
}

export default Writing;