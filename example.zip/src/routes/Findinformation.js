

const Findinformation = () => {
    return (
        <div>
            찾기
        </div>
    )
}

export default Findinformation;