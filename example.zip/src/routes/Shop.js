import { Link } from "react-router-dom";
import { useEffect, useState } from 'react';
import axios from 'axios';
import styles from './shop.css';

const Shop = () => {
    
    // produts에 db 데이터 저장하기 위해 useState 사용
    const [products, setProducts] = useState([{
        id: '',
        name: '',
        description: '',
        price: ''
    }])

    useEffect(() => {
        // 서버단 8000번 shop 페이지에 있는 데이터를 읽기 위해 axios 사용,
        // 비동기작업을 위해 async await
        async function resData() {
            const responces = await axios.get("http://localhost:8000/shop", {})
            const inputData = await responces.data.map((responce) => ({
                id: responce.productCode,
                name: responce.productName,
                description: responce.productDescription,
                price: responce.buyPrice
            }))
            setProducts(inputData);
        }
        resData();
        // try {
        //     axios.get("http://localhost:8000/shop", {})
        //         .then(res => console.log(res))
        // }
        // catch (e) {
        //     console.error(e.message);
        // }
    })

    const onClickBasket = (product) => {
        const baskets = JSON.parse(localStorage.getItem("baskets")) || [];
        baskets.push(product);

        localStorage.setItem("baskets", JSON.stringify(baskets));
    }

    return (
        <div>
            
            <Link to={'/shop/basket'}>
                <img src={'../img/basket.png'} alt='basket' />
            </Link>
            {/* 받은 데이터를 map함수로 화면에 렌더링 */}
            <div>
                {products.map((product) => (
                    <div key={product.id} className={styles.proditem}>
                        <p>{product.name}</p>
                        <p>{product.price}</p>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Shop;