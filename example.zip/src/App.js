import { BrowserRouter as Router, Routes, Route, BrowserRouter } from "react-router-dom";
import './App.css';
import Home from './routes/Home'
import Login from './routes/Login'
import Findinformation from './routes/Findinformation'
import Register from './routes/Register'
import Mypage from './routes/Mypage'
import Carbonfootprint from './routes/Carbonfootprint'
import Environmentalissues from './routes/Environmentalissues'
import Community from './routes/Community'
import Campaign from './routes/Campaign'
import Shop from './routes/Shop'
import Write from './routes/Write'
import Writing from './routes/Writing'
import Campaigndetail from "./routes/Campaigndetail";
import Product from "./routes/Product";
import Shopbasket from "./routes/Shopbasket";


const App = () => {
  return (

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/findinformation" element={<Findinformation />} />
        <Route path="/register" element={<Register />} />
        <Route path="/mypage" element={<Mypage />} />
        <Route path="/carbonfootprint" element={<Carbonfootprint />} />
        <Route path="/environmentalissues" element={<Environmentalissues />} />
        <Route path="/community" element={<Community />} />
        <Route path="/campaign" element={<Campaign />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/community/write" element={<Write />} />
        <Route path="/community/:id" element={<Writing />} />
        <Route path="/campaign/:id" element={<Campaigndetail />} />
        <Route path="/shop/:id" element={<Product />} />
        <Route path="/shop/basket" element={<Shopbasket />} />
      </Routes>

  );
}

export default App;
