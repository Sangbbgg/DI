const express = require('express');
const app = express();
const PORT = process.env.port || 8000;
const mysql = require('mysql2');
const cors = require('cors');

// createConnection - 모듈 호출> db연결 > 쿼리 실행 > 연결 끊기
// 단일연결방식으로 요청이 있을 때마다 연결 객체 생성,제거 따라서 비용,시간,연결에 대한 부담이 발생
// createPool - 미리 정해진 개수의 연결 생성 Request가 발생하면 해당 Req에 연결을 할당하고 다시 반납
// 따라서 단일 연결 방식의 비효율적인 연결 설정에 대한 문제가 해소됨
// 다만 연결 개수에 따라 메모리를 과하게 차지하거나 사용자의 대기시간이 증가할 수 있으므로,
// 사용자 추이를 잘 파악하여 연결 제한 개수를 설정하는 것이 중요

const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "1234",
    database: "classicmodels"
});

// CORS에러 해결 코드

app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    next();
});


app.use(cors({ credentials: true, origin: "*" }));


// .query() 메서드 호출하여 query 수행 .query(sqlString, callback)
app.get("/shop", (req,res) => {
    const sqlQuery = "SELECT * FROM CLASSICMODELS.PRODUCTS;";
    db.query(sqlQuery, (err, result) => {
        res.send(result);
    })
})

app.listen(PORT, () => {
    console.log(`running on port ${PORT}`);
})